﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace LabAssg_2.Migrations
{
    public partial class today : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "MobileCompoany",
                columns: table => new
                {
                    MobileCompanyID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MobileCompanyName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MobileCompoany", x => x.MobileCompanyID);
                });

            migrationBuilder.CreateTable(
                name: "MobileItem",
                columns: table => new
                {
                    MobileItemID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MobileItemName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MobileItemWeight = table.Column<int>(type: "int", nullable: false),
                    MobileItemSize = table.Column<int>(type: "int", nullable: false),
                    MobileItemMfg = table.Column<int>(type: "int", nullable: false),
                    MobileCompanyId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MobileItem", x => x.MobileItemID);
                    table.ForeignKey(
                        name: "FK_MobileItem_MobileCompoany_MobileCompanyId",
                        column: x => x.MobileCompanyId,
                        principalTable: "MobileCompoany",
                        principalColumn: "MobileCompanyID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_MobileItem_MobileCompanyId",
                table: "MobileItem",
                column: "MobileCompanyId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MobileItem");

            migrationBuilder.DropTable(
                name: "MobileCompoany");
        }
    }
}
