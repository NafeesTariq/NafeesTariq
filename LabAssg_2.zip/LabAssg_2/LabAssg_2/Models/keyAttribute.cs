﻿using System;

namespace LabAssg_2.Models
{
    internal class keyAttribute : Attribute
    {
    }
}