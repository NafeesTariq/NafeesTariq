﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace LabAssg_2.Models
{
    public class MobileItem
    {
        [key]
        public int MobileItemID { get; set; }
        public String MobileItemName{ get; set; }
        public int MobileItemWeight { get; set; }
        public int MobileItemSize { get; set; }
        public int MobileItemMfg { get; set; }


        // Foreign key 
        [Display(Name = "MC_Id")]
        public int MobileCompanyId { get; set; }

        [ForeignKey("MobileCompanyId")]
        public virtual MobileCompoany MobileCompoany { get; set; }


    }

    
}
