﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using LabAssg_2.Models;

namespace LabAssg_2.Data
{
    public class LabAssg_2Context : DbContext
    {
        public LabAssg_2Context (DbContextOptions<LabAssg_2Context> options)
            : base(options)
        {
        }

        public DbSet<LabAssg_2.Models.MobileCompoany> MobileCompoany { get; set; }

        public DbSet<LabAssg_2.Models.MobileItem> MobileItem { get; set; }
    }
}
