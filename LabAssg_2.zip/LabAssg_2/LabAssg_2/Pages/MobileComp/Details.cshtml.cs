﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using LabAssg_2.Data;
using LabAssg_2.Models;

namespace LabAssg_2.Pages.MobileComp
{
    public class DetailsModel : PageModel
    {
        private readonly LabAssg_2.Data.LabAssg_2Context _context;

        public DetailsModel(LabAssg_2.Data.LabAssg_2Context context)
        {
            _context = context;
        }

        public MobileCompoany MobileCompoany { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            MobileCompoany = await _context.MobileCompoany.FirstOrDefaultAsync(m => m.MobileCompanyID == id);

            if (MobileCompoany == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
