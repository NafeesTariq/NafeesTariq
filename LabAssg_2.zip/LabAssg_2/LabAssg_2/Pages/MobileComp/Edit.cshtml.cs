﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LabAssg_2.Data;
using LabAssg_2.Models;

namespace LabAssg_2.Pages.MobileComp
{
    public class EditModel : PageModel
    {
        private readonly LabAssg_2.Data.LabAssg_2Context _context;

        public EditModel(LabAssg_2.Data.LabAssg_2Context context)
        {
            _context = context;
        }

        [BindProperty]
        public MobileCompoany MobileCompoany { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            MobileCompoany = await _context.MobileCompoany.FirstOrDefaultAsync(m => m.MobileCompanyID == id);

            if (MobileCompoany == null)
            {
                return NotFound();
            }
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(MobileCompoany).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MobileCompoanyExists(MobileCompoany.MobileCompanyID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool MobileCompoanyExists(int id)
        {
            return _context.MobileCompoany.Any(e => e.MobileCompanyID == id);
        }
    }
}
