﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using LabAssg_2.Data;
using LabAssg_2.Models;

namespace LabAssg_2.Pages.MobileItm
{
    public class EditModel : PageModel
    {
        private readonly LabAssg_2.Data.LabAssg_2Context _context;

        public EditModel(LabAssg_2.Data.LabAssg_2Context context)
        {
            _context = context;
        }

        [BindProperty]
        public MobileItem MobileItem { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            MobileItem = await _context.MobileItem.FirstOrDefaultAsync(m => m.MobileItemID == id);

            if (MobileItem == null)
            {
                return NotFound();
            }
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(MobileItem).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MobileItemExists(MobileItem.MobileItemID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool MobileItemExists(int id)
        {
            return _context.MobileItem.Any(e => e.MobileItemID == id);
        }
    }
}
